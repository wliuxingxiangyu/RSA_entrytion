Android-SMS-Encryption-Decryption-RSA
=====================================

It's Open Project Using RSA Algorithm to Encrypt Entire Message and Send it Automaitcally for Desired Phone Number 
Decrypt It Again Automatically .
