/** Automatically generated file. DO NOT MODIFY */
package com.example.androidrsaproject;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}